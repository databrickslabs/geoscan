from geoscan.geoscan import Geoscan, GeoscanPersonalized
from geoscan.geoscan import GeoscanModel, GeoscanPersonalizedModel